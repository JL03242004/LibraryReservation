<?php
function parse_dt(string $date, string $time): ?DateTime {
    $s = "$date $time"; $d = DateTime::createFromFormat('Y-m-d H:i', $s);
    return ($d && $d->format('Y-m-d H:i') === $s) ? $d : null;
}

/**
 * Create ($resId = null) or update a reservation. Returns a list of error messages ([] = success).
 * $dryRun = true runs every check but saves nothing ("Check availability").
 * Phase 3 will move the overlap check + insert into stored procedure sp_BookRoomReservation.
 */
function save_reservation(array $u, ?int $resId, int $roomId, string $date, string $st, string $en, bool $dryRun = false): array {
    $s = parse_dt($date, $st); $e = parse_dt($date, $en);
    if (!$s || !$e) return ['Enter a valid date, start time and end time.'];
    $err = [];
    if ($e <= $s) $err[] = 'End time must be after the start time.';
    elseif (($e->getTimestamp() - $s->getTimestamp()) > MAX_MINUTES * 60) $err[] = 'Maximum booking duration is 3 hours.';   // BR-01
    if ($s <= new DateTime()) $err[] = 'Reservations cannot be made for past dates or times.';                                  // BR-03
    if ($st < OPEN_TIME || $en > CLOSE_TIME) $err[] = 'The library is open ' . OPEN_TIME . ' to ' . CLOSE_TIME . '.';
    if ($u['account_status'] !== 'Active') $err[] = 'Your account is restricted from booking. Please see the circulation desk.';
    if ($err) return $err;

    $pdo = db(); $sv = $s->format('Y-m-d H:i:s'); $ev = $e->format('Y-m-d H:i:s');
    $pdo->beginTransaction();
    try {
        // Lock the room row so two students cannot book the same slot at once.
        $q = $pdo->prepare("SELECT room_id FROM StudyRoom WHERE room_id = :r AND room_status = 'Available' FOR UPDATE");
        $q->execute([':r' => $roomId]);
        if (!$q->fetch()) { $pdo->rollBack(); return ['That room is not open for booking.']; }

        if ($resId === null) {                                                                                  // BR-02
            $q = $pdo->prepare("SELECT COUNT(*) FROM Reservation WHERE student_id = :s AND status = 'Confirmed' AND start_time > NOW()");
            $q->execute([':s' => $u['student_id']]);
            if ((int)$q->fetchColumn() >= MAX_ACTIVE) { $pdo->rollBack(); return ['You already have ' . MAX_ACTIVE . ' active upcoming reservations. Complete or cancel one first.']; }
        }
        $q = $pdo->prepare("SELECT COUNT(*) FROM Reservation WHERE room_id = :r AND status = 'Confirmed'
                            AND start_time < :e AND end_time > :s AND reservation_id <> :id");                  // BR-04
        $q->execute([':r' => $roomId, ':e' => $ev, ':s' => $sv, ':id' => $resId ?? 0]);
        if ((int)$q->fetchColumn() > 0) { $pdo->rollBack(); return ['That room is already booked for an overlapping time. Pick another time or room.']; }

        if ($dryRun) { $pdo->rollBack(); return []; }
        if ($resId === null) {
            $pdo->prepare("INSERT INTO Reservation (student_id, room_id, start_time, end_time) VALUES (:s,:r,:st,:en)")
                ->execute([':s' => $u['student_id'], ':r' => $roomId, ':st' => $sv, ':en' => $ev]);
        } else {
            $pdo->prepare("UPDATE Reservation SET room_id = :r, start_time = :st, end_time = :en
                           WHERE reservation_id = :id AND student_id = :s AND status = 'Confirmed'")
                ->execute([':r' => $roomId, ':st' => $sv, ':en' => $ev, ':id' => $resId, ':s' => $u['student_id']]);
        }
        $pdo->commit();
        return [];
    } catch (Throwable $t) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $t; }
}
