<?php
function page_header(string $title): void {
    $u = user(); $f = flash(); $cur = basename($_SERVER['PHP_SELF']);
    $links = [];
    if ($u && $u['role'] === 'Student') {
        $links = ['dashboard.php' => 'Dashboard', 'book.php' => 'Book a room', 'rooms.php' => 'Room catalog', 'reservations.php' => 'My reservations'];
    } elseif ($u) {
        $links = ['schedule.php' => 'Master schedule', 'reservations.php' => 'All reservations',
                  'rooms.php' => $u['role'] === 'Admin' ? 'Manage rooms' : 'Room catalog'];
    }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . e($title) . ' | CampusStudy Connect</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="top"><a class="brand" href="index.php">CampusStudy Connect<small>Library room reservations</small></a><nav>';
    foreach ($links as $href => $label) echo '<a href="' . $href . '"' . ($cur === $href ? ' class="on"' : '') . '>' . e($label) . '</a>';
    if ($u) echo '<span class="who">' . e($u['first_name']) . ' (' . e($u['role']) . ')</span><a href="logout.php">Log out</a>';
    echo '</nav></header><main>';
    if ($f) echo '<div class="flash ' . ($f[1] === 'err' ? 'err' : 'ok') . '" role="status">' . e($f[0]) . '</div>';
    echo '<h1>' . e($title) . '</h1>';
}
function page_footer(): void { echo '</main><footer>DBSYS32 / IMDBSYS Phase 2 prototype. University of Cebu, Banilad.</footer></body></html>'; }
function show_errors(array $errs): void {
    if ($errs) { echo '<div class="flash err" role="alert"><ul>'; foreach ($errs as $x) echo '<li>' . e($x) . '</li>'; echo '</ul></div>'; }
}
