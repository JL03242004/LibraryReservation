<?php
// Edit these for your XAMPP / WAMP / MySQL setup.
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('DB_NAME') ?: 'campusstudy_connect');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');

// Business rules (BR-01, BR-02, BR-06) + operating hours
const MAX_MINUTES  = 180;     // BR-01: max 3 hours
const MAX_ACTIVE   = 2;       // BR-02: max 2 active upcoming reservations
const CANCEL_HOURS = 1;       // BR-06: cancel at least 1 hour before start
const OPEN_TIME    = '08:00';
const CLOSE_TIME   = '20:00';
