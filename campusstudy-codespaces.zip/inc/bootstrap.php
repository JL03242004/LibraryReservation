<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Manila');
session_start();
require __DIR__ . '/config.php';

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO(sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME), DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '+08:00'");
    }
    return $pdo;
}
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header("Location: $url"); exit; }
function flash(?string $msg = null, string $type = 'ok') {
    if ($msg !== null) { $_SESSION['flash'] = [$msg, $type]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(array $roles = []): array {
    $u = user();
    if (!$u) redirect('login.php');
    if ($roles && !in_array($u['role'], $roles, true)) { http_response_code(403); exit('403: your role cannot open this page.'); }
    return $u;
}
function csrf_field(): string {
    $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Invalid form token. Go back and reload the page.'); }
}
function badge(string $s): string { return '<span class="badge b-' . strtolower(str_replace([' ', '-'], '', $s)) . '">' . e($s) . '</span>'; }
function fmt_day(string $dt): string { return date('D, M j, Y', strtotime($dt)); }
function fmt_range(string $s, string $e): string { return date('g:i A', strtotime($s)) . ' to ' . date('g:i A', strtotime($e)); }

require __DIR__ . '/layout.php';
require __DIR__ . '/reservations.php';
