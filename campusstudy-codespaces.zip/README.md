# CampusStudy Connect: Library Room Management System (Phase 2)
DBSYS32 / IMDBSYS | Jhon Loyd L. Ambayan (24247710) | PHP 8.1+ / MySQL 8.0 (SQL-only guidelines)

## Setup (XAMPP / WAMP / Laragon)
1. Copy this folder to `htdocs/campusstudy` (or your web root). Start Apache and MySQL.
2. Import the database (phpMyAdmin Import tab, or CLI):
   `mysql -u root -p < sql/schema.sql` then `mysql -u root -p < sql/seed.sql`
3. Edit `inc/config.php` if your MySQL user/password differ.
4. Open `http://localhost/campusstudy/`.

## Demo accounts (password for all: `password`)
| Role | Login |
|---|---|
| Student | 24247710 (jhon.ambayan@uc.edu.ph) |
| Student (2 upcoming, at quota) | 24100001 |
| Student (Restricted, cannot book) | 24100004 |
| Librarian | librarian@uc.edu.ph |
| Admin | admin@uc.edu.ph |

## Phase 2 coverage
| Requirement | Where |
|---|---|
| Create | register.php, book.php, room_form.php (add) |
| Read | dashboard.php, rooms.php (filter/sort), reservations.php, schedule.php |
| Update | reservation_edit.php, room_form.php (edit), reservation_action.php (cancel, check-in status) |
| Delete | room_delete.php (confirm page), reservation_action.php (delete cancelled) |
| JOINs | `sql/join_queries.sql`; used in dashboard, reservations, schedule, rooms |
| Validation | `inc/reservations.php` (BR-01 to BR-04, BR-06 in reservation_action.php), register.php, room_form.php, DB CHECK/UNIQUE/FK |
| Security | PDO prepared statements, password_hash, CSRF tokens, role checks, output escaping |

## Left for Phase 3 (by design)
`sp_BookRoomReservation`, `fn_CalculateReservedMinutes`, `trg_LogReservationCancellation`, audit/analytics panel,
weekly quota (FR-05) and the 2-no-shows-in-a-month restriction (BR-05). The `ReservationAudit` table already exists.
Phase 2 does the overlap check inside a PHP transaction with `SELECT ... FOR UPDATE`; Phase 3 moves it into the procedure.

## Run in GitHub Codespaces
1. Push this folder's contents to the root of a GitHub repo (the `.devcontainer` folder must be at the root).
2. Code > Codespaces > Create codespace on main. First build takes a few minutes; it starts MySQL 8, imports `sql/schema.sql` and `sql/seed.sql`, and serves the app with `php -S` on port 8000.
3. Open the Ports tab and click the globe icon next to port 8000. If the browser did not open automatically, that is how you reach the app.
4. To reset the data: `bash .devcontainer/setup.sh`. If the server stopped: `php -S 0.0.0.0:8000 -t /workspaces/campusstudy &`.
