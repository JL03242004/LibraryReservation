<?php
require __DIR__ . '/inc/bootstrap.php';
$u = user();
if (!$u) redirect('login.php');
redirect($u['role'] === 'Student' ? 'dashboard.php' : 'schedule.php');
