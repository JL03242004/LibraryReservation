# Phase 2 Checkpoint: MySQL Database and Core Web Application (due November 24, 2026)

**Student:** Jhon Loyd L. Ambayan | **ID:** 24247710 | **Section:** Non-Blocked TTH 12:30-3:00PM
**Case study:** No. 03, CampusStudy Connect: Library Room Management System
**Stack:** PHP 8.1 + MySQL 8.0 | **Phase 1 approval date:** ____________

| Evidence item | Student response / link | Status |
|---|---|---|
| Working web app / core CRUD | Screens: login, register, student dashboard, room catalog, book room, my reservations, edit reservation, librarian master schedule, admin room management. Demo: ______ | ☐ Not started ☐ In progress ☐ Done |
| MySQL schema and sample records | `sql/schema.sql` (4 tables, PK/FK, UNIQUE, CHECK incl. 3-hour max), `sql/seed.sql` (7 users, 6 rooms, 10 reservations) | ☐ Not started ☐ In progress ☐ Done |
| Create and update workflows | Create: register, book room, add room. Update: edit reservation, edit room, cancel, check-in (Completed / No-Show). Screenshots: ______ | ☐ Not started ☐ In progress ☐ Done |
| Read and delete workflows | Read: dashboard, catalog with filter/sort, reservation lists, daily schedule. Delete: room (confirmation page), cancelled reservation (confirm dialog). Screenshots: ______ | ☐ Not started ☐ In progress ☐ Done |
| JOIN queries and relationships | `sql/join_queries.sql` Q1 (dashboard), Q2 (master schedule, 3-table JOIN), Q3 (room catalog LEFT JOIN). Output screenshots: ______ | ☐ Not started ☐ In progress ☐ Done |
| Basic input validation | Test table below | ☐ Not started ☐ In progress ☐ Done |
| Evidence / repository / demo | Repo: ______ Demo link: ______ | ☐ Not started ☐ In progress ☐ Done |

## Validation test table (fill Actual and Pass/Fail while running the app)
| # | Test | Input | Expected | Actual | Pass/Fail |
|---|---|---|---|---|---|
| 1 | Valid booking (BR) | Room 1, tomorrow, 09:00-11:00, as 24247710 | Reservation confirmed, appears in My reservations | | |
| 2 | Duration over 3 h (BR-01) | 09:00-13:00 | "Maximum booking duration is 3 hours." | | |
| 3 | Past time (BR-03) | Today, earlier time | "Reservations cannot be made for past dates or times." | | |
| 4 | Overlap (BR-04) | Room 2, tomorrow 14:00-16:00 (Jhon already has 13:00-15:00) | Overlap error, nothing saved | | |
| 5 | Quota (BR-02) | Book as 24100001 | "You already have 2 active upcoming reservations." | | |
| 6 | Restricted account | Book as 24100004 | Booking blocked | | |
| 7 | Cancel inside 1 h (BR-06) | Student cancels a reservation starting in under 1 h | Cancellation denied | | |
| 8 | Cancel valid | Cancel tomorrow's booking | Status becomes Cancelled | | |
| 9 | Duplicate account | Register with existing student no. | "already registered" | | |
| 10 | Weak password / bad email | 5-char password, "abc" email | Field errors shown | | |
| 11 | Room capacity 0 or 31 (admin) | Add room | "Capacity must be between 1 and 30." | | |
| 12 | Delete room with reservations | Delete Room 2 | Refused, suggests Decommissioned | | |
| 13 | Role access | Student opens room_form.php | 403 | | |
| 14 | Check-in | Librarian marks a confirmed booking No-Show | Status updates | | |

**Student reflection / blockers:** ______________________________________________
**Instructor decision:** ☐ ACCEPTED ☐ FOR REVISION ☐ INCOMPLETE
**Instructor remarks:** ______________________________________________________
**Student signature:** Jhon Loyd L. Ambayan  **Instructor:** ____________  **Date:** ________
