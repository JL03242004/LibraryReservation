<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(['Student']);
$rooms = db()->query("SELECT room_id, room_name, capacity FROM StudyRoom WHERE room_status = 'Available' ORDER BY room_name")->fetchAll();
$f = ['room_id' => (int)($_GET['room_id'] ?? 0), 'date' => date('Y-m-d', strtotime('+1 day')), 'start' => '09:00', 'end' => '10:00'];
$errs = []; $okMsg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f = ['room_id' => (int)($_POST['room_id'] ?? 0), 'date' => $_POST['date'] ?? '', 'start' => $_POST['start'] ?? '', 'end' => $_POST['end'] ?? ''];
    $check = isset($_POST['check']);
    if (!$f['room_id']) $errs[] = 'Choose a study room.';
    else $errs = save_reservation($u, null, $f['room_id'], $f['date'], $f['start'], $f['end'], $check);
    if (!$errs && $check) $okMsg = 'That room is free for the selected time. Confirm the booking to reserve it.';
    elseif (!$errs) { flash('Reservation confirmed.'); redirect('reservations.php'); }
}
page_header('Book a room');
show_errors($errs);
if ($okMsg) echo '<div class="flash ok" role="status">' . e($okMsg) . '</div>';
?>
<div class="card"><form method="post" class="stack">
  <?= csrf_field() ?>
  <label>Study room<select name="room_id" required><option value="">Select a room</option>
    <?php foreach ($rooms as $r): ?><option value="<?= (int)$r['room_id'] ?>" <?= $f['room_id'] === (int)$r['room_id'] ? 'selected' : '' ?>><?= e($r['room_name']) ?> (seats <?= (int)$r['capacity'] ?>)</option><?php endforeach; ?></select></label>
  <label>Date<input type="date" name="date" value="<?= e($f['date']) ?>" min="<?= date('Y-m-d') ?>" required></label>
  <div class="row">
    <label>Start time<input type="time" name="start" value="<?= e($f['start']) ?>" min="<?= OPEN_TIME ?>" max="<?= CLOSE_TIME ?>" step="1800" required></label>
    <label>End time<input type="time" name="end" value="<?= e($f['end']) ?>" min="<?= OPEN_TIME ?>" max="<?= CLOSE_TIME ?>" step="1800" required></label>
  </div>
  <p class="muted">Up to 3 hours per booking, <?= OPEN_TIME ?> to <?= CLOSE_TIME ?>. You can hold <?= MAX_ACTIVE ?> upcoming reservations at a time.</p>
  <div class="actions"><button name="check" value="1" class="alt">Check availability</button><button>Confirm booking</button></div>
</form></div>
<?php page_footer();
