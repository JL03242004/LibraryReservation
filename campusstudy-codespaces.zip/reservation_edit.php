<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(['Student']);
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$q = db()->prepare("SELECT * FROM Reservation WHERE reservation_id = :i AND student_id = :s AND status = 'Confirmed' AND start_time > NOW()");
$q->execute([':i' => $id, ':s' => $u['student_id']]); $r = $q->fetch();
if (!$r) { flash('That reservation cannot be edited.', 'err'); redirect('reservations.php'); }
$rooms = db()->query("SELECT room_id, room_name, capacity FROM StudyRoom WHERE room_status = 'Available' ORDER BY room_name")->fetchAll();
$f = ['room_id' => (int)$r['room_id'], 'date' => date('Y-m-d', strtotime($r['start_time'])), 'start' => date('H:i', strtotime($r['start_time'])), 'end' => date('H:i', strtotime($r['end_time']))];
$errs = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f = ['room_id' => (int)($_POST['room_id'] ?? 0), 'date' => $_POST['date'] ?? '', 'start' => $_POST['start'] ?? '', 'end' => $_POST['end'] ?? ''];
    $errs = save_reservation($u, $id, $f['room_id'], $f['date'], $f['start'], $f['end']);
    if (!$errs) { flash('Reservation updated.'); redirect('reservations.php'); }
}
page_header('Edit reservation');
show_errors($errs);
?>
<div class="card"><form method="post" class="stack">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <label>Study room<select name="room_id"><?php foreach ($rooms as $x): ?>
    <option value="<?= (int)$x['room_id'] ?>" <?= $f['room_id'] === (int)$x['room_id'] ? 'selected' : '' ?>><?= e($x['room_name']) ?> (seats <?= (int)$x['capacity'] ?>)</option><?php endforeach; ?></select></label>
  <label>Date<input type="date" name="date" value="<?= e($f['date']) ?>" min="<?= date('Y-m-d') ?>" required></label>
  <div class="row">
    <label>Start time<input type="time" name="start" value="<?= e($f['start']) ?>" step="1800" required></label>
    <label>End time<input type="time" name="end" value="<?= e($f['end']) ?>" step="1800" required></label>
  </div>
  <div class="actions"><button>Save changes</button><a class="btn alt" href="reservations.php">Back</a></div>
</form></div>
<?php page_footer();
