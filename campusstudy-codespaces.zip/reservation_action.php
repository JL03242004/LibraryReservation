<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(); $staff = $u['role'] !== 'Student';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('reservations.php');
csrf_check();
$id = (int)($_POST['id'] ?? 0); $act = $_POST['action'] ?? '';
$date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['date'] ?? '') ? $_POST['date'] : '';
$back = ($_POST['back'] ?? '') === 'schedule' ? 'schedule.php?date=' . $date : 'reservations.php';

$q = db()->prepare('SELECT * FROM Reservation WHERE reservation_id = :i'); $q->execute([':i' => $id]); $r = $q->fetch();
if (!$r || (!$staff && (int)$r['student_id'] !== (int)$u['student_id'])) { flash('Reservation not found.', 'err'); redirect($back); }

$set = fn(string $status) => db()->prepare('UPDATE Reservation SET status = :s WHERE reservation_id = :i')->execute([':s' => $status, ':i' => $id]);
switch ($act) {
    case 'cancel':
        if ($r['status'] !== 'Confirmed') flash('Only confirmed reservations can be cancelled.', 'err');
        elseif (!$staff && strtotime($r['start_time']) - time() < CANCEL_HOURS * 3600) flash('Cancellations must be made at least 1 hour before the start time.', 'err');   // BR-06
        else { $set('Cancelled'); flash('Reservation cancelled.'); }
        break;
    case 'delete':
        if ($r['status'] !== 'Cancelled') flash('Only cancelled reservations can be deleted.', 'err');
        else { db()->prepare('DELETE FROM Reservation WHERE reservation_id = :i')->execute([':i' => $id]); flash('Reservation deleted.'); }
        break;
    case 'complete': case 'noshow':
        if (!$staff) flash('Only library staff can check in groups.', 'err');
        elseif ($r['status'] !== 'Confirmed') flash('Only confirmed reservations can be checked in.', 'err');
        else { $set($act === 'complete' ? 'Completed' : 'No-Show'); flash('Reservation marked ' . ($act === 'complete' ? 'Completed' : 'No-Show') . '.'); }
        break;
    default: flash('Unknown action.', 'err');
}
redirect($back);
