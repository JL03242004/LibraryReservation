#!/usr/bin/env bash
set -e
cd /workspaces/campusstudy
echo "Waiting for MySQL..."
for i in $(seq 1 60); do
  mysql -h db -uroot -proot -e 'SELECT 1' >/dev/null 2>&1 && break
  sleep 2
done
mysql -h db -uroot -proot < sql/schema.sql
mysql -h db -uroot -proot < sql/seed.sql
echo "Database ready. Open the forwarded port 8000."
