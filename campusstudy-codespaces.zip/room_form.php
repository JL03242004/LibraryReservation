<?php
require __DIR__ . '/inc/bootstrap.php';
require_login(['Admin']);
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$room = ['room_name' => '', 'capacity' => '', 'has_projector' => 0, 'has_whiteboard' => 0, 'room_status' => 'Available'];
if ($id) {
    $q = db()->prepare('SELECT * FROM StudyRoom WHERE room_id = :i'); $q->execute([':i' => $id]);
    $room = $q->fetch() ?: null;
    if (!$room) { flash('Room not found.', 'err'); redirect('rooms.php'); }
}
$errs = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $room = ['room_name' => trim($_POST['room_name'] ?? ''), 'capacity' => (int)($_POST['capacity'] ?? 0),
             'has_projector' => isset($_POST['has_projector']) ? 1 : 0, 'has_whiteboard' => isset($_POST['has_whiteboard']) ? 1 : 0,
             'room_status' => $_POST['room_status'] ?? ''];
    if ($room['room_name'] === '' || mb_strlen($room['room_name']) > 50) $errs[] = 'Room name is required (max 50 characters).';
    if ($room['capacity'] < 1 || $room['capacity'] > 30) $errs[] = 'Capacity must be between 1 and 30.';
    if (!in_array($room['room_status'], ['Available', 'Maintenance', 'Decommissioned'], true)) $errs[] = 'Choose a valid status.';
    if (!$errs) {
        $args = [':n' => $room['room_name'], ':c' => $room['capacity'], ':p' => $room['has_projector'], ':w' => $room['has_whiteboard'], ':s' => $room['room_status']];
        try {
            if ($id) { $args[':i'] = $id; db()->prepare('UPDATE StudyRoom SET room_name=:n, capacity=:c, has_projector=:p, has_whiteboard=:w, room_status=:s WHERE room_id=:i')->execute($args); }
            else db()->prepare('INSERT INTO StudyRoom (room_name, capacity, has_projector, has_whiteboard, room_status) VALUES (:n,:c,:p,:w,:s)')->execute($args);
            flash($id ? 'Room updated.' : 'Room added.'); redirect('rooms.php');
        } catch (PDOException $ex) {
            if (($ex->errorInfo[1] ?? 0) === 1062) $errs[] = 'A room with that name already exists.'; else throw $ex;
        }
    }
}
page_header($id ? 'Edit room' : 'Add room');
show_errors($errs);
?>
<div class="card"><form method="post" class="stack">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
  <label>Room name<input name="room_name" value="<?= e($room['room_name']) ?>" maxlength="50" required></label>
  <label>Capacity (1 to 30)<input type="number" name="capacity" min="1" max="30" value="<?= e($room['capacity']) ?>" required></label>
  <label class="check"><input type="checkbox" name="has_projector" <?= $room['has_projector'] ? 'checked' : '' ?>>Has projector</label>
  <label class="check"><input type="checkbox" name="has_whiteboard" <?= $room['has_whiteboard'] ? 'checked' : '' ?>>Has whiteboard</label>
  <label>Status<select name="room_status"><?php foreach (['Available', 'Maintenance', 'Decommissioned'] as $s): ?>
    <option <?= $room['room_status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select></label>
  <div class="actions"><button>Save room</button><a class="btn alt" href="rooms.php">Cancel</a></div>
</form></div>
<?php page_footer();
