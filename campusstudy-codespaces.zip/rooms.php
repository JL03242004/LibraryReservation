<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(); $admin = $u['role'] === 'Admin';
$where = []; $p = [];
if (!$admin) $where[] = "r.room_status <> 'Decommissioned'";
$cap = (int)($_GET['capacity'] ?? 0);
if ($cap > 0) { $where[] = 'r.capacity >= :cap'; $p[':cap'] = $cap; }
if (!empty($_GET['projector']))  $where[] = 'r.has_projector = 1';
if (!empty($_GET['whiteboard'])) $where[] = 'r.has_whiteboard = 1';
$sorts = ['name' => 'r.room_name', 'cap_asc' => 'r.capacity, r.room_name', 'cap_desc' => 'r.capacity DESC, r.room_name'];
$sort = $sorts[$_GET['sort'] ?? 'name'] ?? $sorts['name'];
$sql = "SELECT r.*, EXISTS(SELECT 1 FROM Reservation x WHERE x.room_id = r.room_id AND x.status = 'Confirmed'
        AND x.start_time <= NOW() AND x.end_time > NOW()) AS in_use FROM StudyRoom r"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY $sort";
$q = db()->prepare($sql); $q->execute($p); $rooms = $q->fetchAll();

page_header($admin ? 'Manage rooms' : 'Room catalog');
?>
<form method="get" class="card row" style="margin-bottom:1rem">
  <label>Minimum capacity<input type="number" name="capacity" min="1" max="30" value="<?= $cap ?: '' ?>"></label>
  <label>Sort by<select name="sort">
    <?php foreach (['name' => 'Room name', 'cap_asc' => 'Capacity, low to high', 'cap_desc' => 'Capacity, high to low'] as $k => $l): ?>
    <option value="<?= $k ?>" <?= ($_GET['sort'] ?? 'name') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></label>
  <label class="check"><input type="checkbox" name="projector" value="1" <?= !empty($_GET['projector']) ? 'checked' : '' ?>>Projector</label>
  <label class="check"><input type="checkbox" name="whiteboard" value="1" <?= !empty($_GET['whiteboard']) ? 'checked' : '' ?>>Whiteboard</label>
  <button>Apply filters</button>
</form>
<?php if ($admin): ?><p><a class="btn" href="room_form.php">Add room</a></p><?php endif; ?>
<?php if (!$rooms): ?><p class="muted">No rooms match those filters. Clear a filter to see more.</p><?php else: ?>
<div class="scroll"><table>
<tr><th>Room</th><th>Capacity</th><th>Projector</th><th>Whiteboard</th><th>Status</th><th></th></tr>
<?php foreach ($rooms as $r): ?>
<tr><td><?= e($r['room_name']) ?></td><td><?= (int)$r['capacity'] ?></td>
<td><?= $r['has_projector'] ? 'Yes' : 'No' ?></td><td><?= $r['has_whiteboard'] ? 'Yes' : 'No' ?></td>
<td><?= $r['room_status'] === 'Available' ? badge($r['in_use'] ? 'In use' : 'Free now') : badge($r['room_status']) ?></td>
<td class="actions">
<?php if ($u['role'] === 'Student' && $r['room_status'] === 'Available'): ?><a class="btn sm" href="book.php?room_id=<?= (int)$r['room_id'] ?>">Book</a><?php endif; ?>
<?php if ($admin): ?><a class="btn sm alt" href="room_form.php?id=<?= (int)$r['room_id'] ?>">Edit</a><a class="btn sm danger" href="room_delete.php?id=<?= (int)$r['room_id'] ?>">Delete</a><?php endif; ?>
</td></tr>
<?php endforeach; ?></table></div><?php endif; ?>
<?php page_footer();
