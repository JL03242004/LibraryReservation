<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(); $staff = $u['role'] !== 'Student';
$statuses = ['Confirmed', 'Completed', 'Cancelled', 'No-Show'];
$st = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';
$where = []; $p = [];
if (!$staff) { $where[] = 'r.student_id = :sid'; $p[':sid'] = $u['student_id']; }
if ($st) { $where[] = 'r.status = :st'; $p[':st'] = $st; }
$q = db()->prepare("SELECT r.*, s.room_name, CONCAT(t.first_name, ' ', t.last_name) AS student_name, t.student_no
    FROM Reservation r JOIN StudyRoom s ON s.room_id = r.room_id JOIN Student t ON t.student_id = r.student_id"
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY r.start_time DESC');
$q->execute($p); $rows = $q->fetchAll();
page_header($staff ? 'All reservations' : 'My reservations');
?>
<form method="get" class="card row" style="margin-bottom:1rem">
  <label>Status<select name="status"><option value="">All</option>
    <?php foreach ($statuses as $s): ?><option <?= $st === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select></label>
  <button>Filter</button>
</form>
<?php if (!$rows): ?><p class="muted">No reservations found.<?= $staff ? '' : ' <a href="book.php">Book a room</a>.' ?></p><?php else: ?>
<div class="scroll"><table>
<tr><th>Room</th><?php if ($staff): ?><th>Booked by</th><?php endif; ?><th>Date</th><th>Time</th><th>Status</th><th></th></tr>
<?php foreach ($rows as $r):
  $upcoming = $r['status'] === 'Confirmed' && strtotime($r['start_time']) > time(); ?>
<tr><td><?= e($r['room_name']) ?></td>
<?php if ($staff): ?><td><?= e($r['student_name']) ?> <span class="muted">(<?= e($r['student_no']) ?>)</span></td><?php endif; ?>
<td><?= fmt_day($r['start_time']) ?></td><td><?= fmt_range($r['start_time'], $r['end_time']) ?></td><td><?= badge($r['status']) ?></td>
<td class="actions">
<?php if ($upcoming && !$staff): ?><a class="btn sm alt" href="reservation_edit.php?id=<?= (int)$r['reservation_id'] ?>">Edit</a><?php endif; ?>
<?php foreach (($upcoming ? ['cancel' => 'Cancel'] : []) + ($r['status'] === 'Cancelled' ? ['delete' => 'Delete'] : []) as $act => $label): ?>
<form method="post" action="reservation_action.php" class="inline" onsubmit="return confirm('<?= $label ?> this reservation?')">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['reservation_id'] ?>"><input type="hidden" name="action" value="<?= $act ?>">
  <button class="sm danger"><?= $label ?></button></form>
<?php endforeach; ?>
</td></tr>
<?php endforeach; ?></table></div><?php endif; ?>
<?php page_footer();
