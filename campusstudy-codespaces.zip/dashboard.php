<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_login(['Student']);
$pdo = db();
$q = $pdo->prepare("SELECT COUNT(*) FROM Reservation WHERE student_id = :s AND status = 'Confirmed' AND start_time > NOW()");
$q->execute([':s' => $u['student_id']]); $active = (int)$q->fetchColumn();
$free = (int)$pdo->query("SELECT COUNT(*) FROM StudyRoom r WHERE room_status = 'Available' AND NOT EXISTS
    (SELECT 1 FROM Reservation x WHERE x.room_id = r.room_id AND x.status = 'Confirmed' AND x.start_time <= NOW() AND x.end_time > NOW())")->fetchColumn();

$q = $pdo->prepare("SELECT r.reservation_id, s.room_name, r.start_time, r.end_time, r.status
    FROM Reservation r JOIN StudyRoom s ON s.room_id = r.room_id
    WHERE r.student_id = :s AND r.status = 'Confirmed' AND r.start_time > NOW() ORDER BY r.start_time LIMIT 5");
$q->execute([':s' => $u['student_id']]); $upcoming = $q->fetchAll();

$q = $pdo->prepare("SELECT s.room_name, r.start_time, r.end_time, r.status
    FROM Reservation r JOIN StudyRoom s ON s.room_id = r.room_id
    WHERE r.student_id = :s AND NOT (r.status = 'Confirmed' AND r.start_time > NOW()) ORDER BY r.start_time DESC LIMIT 5");
$q->execute([':s' => $u['student_id']]); $history = $q->fetchAll();

page_header('Welcome, ' . $u['first_name']);
?>
<div class="stats">
  <div class="card stat"><b><?= $active ?> of <?= MAX_ACTIVE ?></b><span>active upcoming reservations</span></div>
  <div class="card stat"><b><?= $free ?></b><span>rooms free right now</span></div>
  <div class="card stat"><b><?= date('M j') ?></b><span><?= date('l, Y') ?></span></div>
</div>
<?php if ($u['account_status'] !== 'Active'): ?><div class="flash err">Your account is <?= e($u['account_status']) ?>. You cannot book rooms until the library lifts the restriction.</div><?php endif; ?>
<p><a class="btn" href="book.php">Book a room</a> <a class="btn alt" href="rooms.php">Browse rooms</a></p>

<h2>Upcoming reservations</h2>
<?php if (!$upcoming): ?><p class="muted">No upcoming reservations. Book a room to get started.</p><?php else: ?>
<div class="scroll"><table><tr><th>Room</th><th>Date</th><th>Time</th><th>Status</th></tr>
<?php foreach ($upcoming as $r): ?><tr><td><?= e($r['room_name']) ?></td><td><?= fmt_day($r['start_time']) ?></td><td><?= fmt_range($r['start_time'], $r['end_time']) ?></td><td><?= badge($r['status']) ?></td></tr><?php endforeach; ?>
</table></div><?php endif; ?>
<p><a href="reservations.php">View all reservations</a></p>

<h2>Recent history</h2>
<?php if (!$history): ?><p class="muted">Nothing here yet.</p><?php else: ?>
<div class="scroll"><table><tr><th>Room</th><th>Date</th><th>Time</th><th>Status</th></tr>
<?php foreach ($history as $r): ?><tr><td><?= e($r['room_name']) ?></td><td><?= fmt_day($r['start_time']) ?></td><td><?= fmt_range($r['start_time'], $r['end_time']) ?></td><td><?= badge($r['status']) ?></td></tr><?php endforeach; ?>
</table></div><?php endif; ?>
<?php page_footer();
