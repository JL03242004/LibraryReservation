<?php
require __DIR__ . '/inc/bootstrap.php';
require_login(['Librarian', 'Admin']);
$date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'] ?? '') ? $_GET['date'] : date('Y-m-d');
$q = db()->prepare("SELECT r.reservation_id, r.start_time, r.end_time, r.status, s.room_name,
        CONCAT(t.first_name, ' ', t.last_name) AS student_name, t.student_no
    FROM Reservation r JOIN StudyRoom s ON s.room_id = r.room_id JOIN Student t ON t.student_id = r.student_id
    WHERE DATE(r.start_time) = :d ORDER BY s.room_name, r.start_time");
$q->execute([':d' => $date]); $rows = $q->fetchAll();
page_header('Master schedule');
?>
<form method="get" class="card row" style="margin-bottom:1rem">
  <label>Date<input type="date" name="date" value="<?= e($date) ?>"></label><button>Show day</button>
</form>
<h2><?= fmt_day($date) ?></h2>
<?php if (!$rows): ?><p class="muted">No reservations on this date.</p><?php else: ?>
<div class="scroll"><table>
<tr><th>Room</th><th>Time</th><th>Booked by</th><th>Status</th><th>Check-in</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['room_name']) ?></td><td><?= fmt_range($r['start_time'], $r['end_time']) ?></td>
<td><?= e($r['student_name']) ?> <span class="muted">(<?= e($r['student_no']) ?>)</span></td><td><?= badge($r['status']) ?></td>
<td class="actions"><?php if ($r['status'] === 'Confirmed'): foreach (['complete' => 'Mark completed', 'noshow' => 'Mark no-show'] as $a => $l): ?>
<form method="post" action="reservation_action.php" class="inline"><?= csrf_field() ?>
<input type="hidden" name="id" value="<?= (int)$r['reservation_id'] ?>"><input type="hidden" name="action" value="<?= $a ?>">
<input type="hidden" name="back" value="schedule"><input type="hidden" name="date" value="<?= e($date) ?>">
<button class="sm <?= $a === 'noshow' ? 'danger' : '' ?>"><?= $l ?></button></form>
<?php endforeach; endif; ?></td></tr>
<?php endforeach; ?></table></div><?php endif; ?>
<?php page_footer();
