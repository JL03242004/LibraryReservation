-- CampusStudy Connect: Library Room Management System
-- Phase 2 schema (MySQL 8.0+). Author: Jhon Loyd L. Ambayan (24247710)
DROP DATABASE IF EXISTS campusstudy_connect;
CREATE DATABASE campusstudy_connect CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE campusstudy_connect;

-- Student table also holds staff accounts; `role` supports role-based access (FR-12).
CREATE TABLE Student (
  student_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_no     VARCHAR(12)  NOT NULL,
  first_name     VARCHAR(50)  NOT NULL,
  last_name      VARCHAR(50)  NOT NULL,
  email          VARCHAR(100) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('Student','Librarian','Admin') NOT NULL DEFAULT 'Student',
  account_status ENUM('Active','Restricted','Disabled') NOT NULL DEFAULT 'Active',
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (student_id),
  UNIQUE KEY uq_student_no (student_no),
  UNIQUE KEY uq_student_email (email),
  CONSTRAINT chk_email_format CHECK (email LIKE '%_@_%._%')
) ENGINE=InnoDB;

CREATE TABLE StudyRoom (
  room_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  room_name      VARCHAR(50)  NOT NULL,
  capacity       TINYINT UNSIGNED NOT NULL,
  has_projector  TINYINT(1)   NOT NULL DEFAULT 0,
  has_whiteboard TINYINT(1)   NOT NULL DEFAULT 0,
  room_status    ENUM('Available','Maintenance','Decommissioned') NOT NULL DEFAULT 'Available',
  PRIMARY KEY (room_id),
  UNIQUE KEY uq_room_name (room_name),
  CONSTRAINT chk_room_capacity CHECK (capacity BETWEEN 1 AND 30)
) ENGINE=InnoDB;

CREATE TABLE Reservation (
  reservation_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id     INT UNSIGNED NOT NULL,
  room_id        INT UNSIGNED NOT NULL,
  start_time     DATETIME     NOT NULL,
  end_time       DATETIME     NOT NULL,
  status         ENUM('Confirmed','Cancelled','Completed','No-Show') NOT NULL DEFAULT 'Confirmed',
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (reservation_id),
  KEY idx_res_room_time (room_id, start_time, end_time),
  KEY idx_res_student (student_id, status),
  CONSTRAINT fk_res_student FOREIGN KEY (student_id) REFERENCES Student(student_id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_res_room FOREIGN KEY (room_id) REFERENCES StudyRoom(room_id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_res_order CHECK (end_time > start_time),
  CONSTRAINT chk_res_max3h CHECK (end_time <= start_time + INTERVAL 3 HOUR)   -- BR-01
) ENGINE=InnoDB;

-- Created now so the design matches the approved ERD; populated by a trigger in Phase 3.
CREATE TABLE ReservationAudit (
  audit_id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reservation_id   INT UNSIGNED NULL,
  action_performed VARCHAR(60)  NOT NULL,
  performed_by     INT UNSIGNED NULL,
  `timestamp`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (audit_id),
  CONSTRAINT fk_audit_res FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_audit_user FOREIGN KEY (performed_by) REFERENCES Student(student_id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;
