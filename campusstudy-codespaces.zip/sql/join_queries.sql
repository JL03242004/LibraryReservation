USE campusstudy_connect;
-- Q1  Student Dashboard / My reservations   (Reservation + StudyRoom)
SELECT r.reservation_id, s.room_name, r.start_time, r.end_time, r.status
FROM Reservation r JOIN StudyRoom s ON s.room_id = r.room_id
WHERE r.student_id = 3 ORDER BY r.start_time DESC;

-- Q2  Librarian Master Schedule              (Reservation + StudyRoom + Student)
SELECT s.room_name, CONCAT(st.first_name,' ',st.last_name) AS booked_by,
       r.start_time, r.end_time, r.status
FROM Reservation r
JOIN StudyRoom s  ON s.room_id = r.room_id
JOIN Student  st  ON st.student_id = r.student_id
WHERE DATE(r.start_time) = CURDATE()
ORDER BY s.room_name, r.start_time;

-- Q3  Room catalog with live occupancy       (StudyRoom LEFT JOIN Reservation)
SELECT s.room_name, s.capacity, s.room_status,
       IF(r.reservation_id IS NULL,'Free now','In use') AS now_status
FROM StudyRoom s
LEFT JOIN Reservation r ON r.room_id = s.room_id AND r.status = 'Confirmed'
                       AND r.start_time <= NOW() AND r.end_time > NOW();
