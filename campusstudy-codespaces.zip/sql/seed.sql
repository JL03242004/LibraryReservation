USE campusstudy_connect;
-- All demo accounts use the password:  password
INSERT INTO Student (student_no, first_name, last_name, email, password_hash, role, account_status) VALUES
('00000001','Library','Admin','admin@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Admin','Active'),
('00000002','Lia','Librarian','librarian@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Librarian','Active'),
('24247710','Jhon Loyd','Ambayan','jhon.ambayan@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Student','Active'),
('24100001','Maria','Santos','maria.santos@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Student','Active'),
('24100002','Juan','Dela Cruz','juan.delacruz@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Student','Active'),
('24100003','Ana','Reyes','ana.reyes@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Student','Active'),
('24100004','Carlo','Villanueva','carlo.v@uc.edu.ph','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Student','Restricted');

INSERT INTO StudyRoom (room_name, capacity, has_projector, has_whiteboard, room_status) VALUES
('Room 1',4,0,1,'Available'),
('Room 2',6,1,1,'Available'),
('Room 3',8,1,1,'Available'),
('Room 4',10,1,0,'Available'),
('Quiet Pod A',2,0,0,'Available'),
('Seminar Room',20,1,1,'Maintenance');

-- Times are relative to today so the demo always has current data.
-- student_id: 3=Jhon, 4=Maria, 5=Juan, 6=Ana   | room_id: 1..6
INSERT INTO Reservation (student_id, room_id, start_time, end_time, status) VALUES
(3,2, TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'13:00:00'), TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'15:00:00'),'Confirmed'),
(3,1, TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 3 DAY),'09:00:00'), TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 3 DAY),'11:00:00'),'Completed'),
(3,3, TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'14:00:00'), TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'15:00:00'),'Cancelled'),
(4,2, TIMESTAMP(CURDATE(),'16:00:00'), TIMESTAMP(CURDATE(),'18:00:00'),'Confirmed'),
(4,4, TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 2 DAY),'10:00:00'), TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 2 DAY),'12:00:00'),'Confirmed'),
(5,1, TIMESTAMP(CURDATE(),'17:00:00'), TIMESTAMP(CURDATE(),'19:00:00'),'Confirmed'),
(5,3, TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'09:00:00'), TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'12:00:00'),'Confirmed'),
(6,5, TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 2 DAY),'13:00:00'), TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL 2 DAY),'14:00:00'),'No-Show'),
(6,3, TIMESTAMP(CURDATE(),'18:00:00'), TIMESTAMP(CURDATE(),'19:30:00'),'Confirmed'),
(4,5, TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'10:00:00'), TIMESTAMP(DATE_ADD(CURDATE(),INTERVAL 1 DAY),'11:00:00'),'Confirmed');  -- Maria now has 2 upcoming (quota demo)
