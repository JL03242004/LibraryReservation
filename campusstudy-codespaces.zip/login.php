<?php
require __DIR__ . '/inc/bootstrap.php';
if (user()) redirect('index.php');
$errs = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = trim($_POST['identifier'] ?? ''); $pw = $_POST['password'] ?? '';
    if ($id === '' || $pw === '') $errs[] = 'Enter your email or student number and your password.';
    else {
        $q = db()->prepare('SELECT * FROM Student WHERE email = :a OR student_no = :b LIMIT 1');
        $q->execute([':a' => $id, ':b' => $id]);
        $row = $q->fetch();
        if (!$row || !password_verify($pw, $row['password_hash'])) $errs[] = 'Incorrect email/student number or password.';
        elseif ($row['account_status'] === 'Disabled') $errs[] = 'This account is disabled. Contact the library.';
        else {
            session_regenerate_id(true);
            unset($row['password_hash']);
            $_SESSION['user'] = $row;
            redirect('index.php');
        }
    }
}
page_header('Log in');
show_errors($errs);
?>
<div class="card login">
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <label>Email or student number<input name="identifier" value="<?= e($_POST['identifier'] ?? '') ?>" autocomplete="username" required></label>
    <label>Password<input type="password" name="password" autocomplete="current-password" required></label>
    <button>Log in</button>
    <a class="btn alt" href="register.php">Create student account</a>
  </form>
</div>
<?php page_footer();
