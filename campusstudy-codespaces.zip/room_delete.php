<?php
require __DIR__ . '/inc/bootstrap.php';
require_login(['Admin']);
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$q = db()->prepare('SELECT * FROM StudyRoom WHERE room_id = :i'); $q->execute([':i' => $id]);
$room = $q->fetch();
if (!$room) { flash('Room not found.', 'err'); redirect('rooms.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        db()->prepare('DELETE FROM StudyRoom WHERE room_id = :i')->execute([':i' => $id]);
        flash('Room deleted.');
    } catch (PDOException $ex) {
        if (($ex->errorInfo[1] ?? 0) === 1451) flash('This room has reservation records and cannot be deleted. Set its status to Decommissioned instead.', 'err'); else throw $ex;
    }
    redirect('rooms.php');
}
page_header('Delete room');
?>
<div class="card"><p>Delete <strong><?= e($room['room_name']) ?></strong> (capacity <?= (int)$room['capacity'] ?>)? This cannot be undone.</p>
<form method="post" class="actions"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
<button class="danger">Yes, delete room</button><a class="btn alt" href="rooms.php">Keep room</a></form></div>
<?php page_footer();
