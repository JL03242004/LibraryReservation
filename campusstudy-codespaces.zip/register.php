<?php
require __DIR__ . '/inc/bootstrap.php';
if (user()) redirect('index.php');
$errs = []; $v = ['student_no' => '', 'first_name' => '', 'last_name' => '', 'email' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($v as $k => $_) $v[$k] = trim($_POST[$k] ?? '');
    $pw = $_POST['password'] ?? ''; $pw2 = $_POST['confirm'] ?? '';
    if (!preg_match('/^\d{8}$/', $v['student_no'])) $errs[] = 'Student number must be 8 digits.';
    if ($v['first_name'] === '' || mb_strlen($v['first_name']) > 50) $errs[] = 'First name is required (max 50 characters).';
    if ($v['last_name'] === '' || mb_strlen($v['last_name']) > 50) $errs[] = 'Last name is required (max 50 characters).';
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($v['email']) > 100) $errs[] = 'Enter a valid email address.';
    if (strlen($pw) < 8) $errs[] = 'Password must be at least 8 characters.';
    if ($pw !== $pw2) $errs[] = 'Passwords do not match.';
    if (!$errs) {
        try {
            db()->prepare("INSERT INTO Student (student_no, first_name, last_name, email, password_hash) VALUES (:n,:f,:l,:e,:p)")
                ->execute([':n' => $v['student_no'], ':f' => $v['first_name'], ':l' => $v['last_name'], ':e' => $v['email'], ':p' => password_hash($pw, PASSWORD_DEFAULT)]);
            flash('Account created. You can log in now.');
            redirect('login.php');
        } catch (PDOException $ex) {
            if (($ex->errorInfo[1] ?? 0) === 1062) $errs[] = 'That student number or email is already registered.'; else throw $ex;
        }
    }
}
page_header('Create student account');
show_errors($errs);
?>
<div class="card"><form method="post" class="stack">
  <?= csrf_field() ?>
  <label>Student number<input name="student_no" value="<?= e($v['student_no']) ?>" inputmode="numeric" maxlength="8" required></label>
  <div class="row">
    <label>First name<input name="first_name" value="<?= e($v['first_name']) ?>" required></label>
    <label>Last name<input name="last_name" value="<?= e($v['last_name']) ?>" required></label>
  </div>
  <label>University email<input type="email" name="email" value="<?= e($v['email']) ?>" required></label>
  <label>Password (8+ characters)<input type="password" name="password" minlength="8" required></label>
  <label>Confirm password<input type="password" name="confirm" minlength="8" required></label>
  <button>Create account</button>
  <a href="login.php">Back to log in</a>
</form></div>
<?php page_footer();
